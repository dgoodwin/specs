package liquibase.logging;

public enum LogLevel {
    OFF, DEBUG, INFO, WARNING, SEVERE;

}
