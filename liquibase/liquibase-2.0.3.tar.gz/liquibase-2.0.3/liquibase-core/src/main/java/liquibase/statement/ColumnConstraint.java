package liquibase.statement;

public interface ColumnConstraint {
}
