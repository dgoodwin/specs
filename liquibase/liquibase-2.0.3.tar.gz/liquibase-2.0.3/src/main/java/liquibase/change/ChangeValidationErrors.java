package liquibase.change;

public class ChangeValidationErrors {
}
