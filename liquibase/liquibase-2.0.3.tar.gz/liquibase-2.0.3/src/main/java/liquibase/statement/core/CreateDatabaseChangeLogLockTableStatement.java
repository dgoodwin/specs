package liquibase.statement.core;

import liquibase.statement.AbstractSqlStatement;

public class CreateDatabaseChangeLogLockTableStatement extends AbstractSqlStatement {
}
